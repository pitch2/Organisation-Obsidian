### Voici une notes de liens utiles, des ressources intéressantes ou autre 

